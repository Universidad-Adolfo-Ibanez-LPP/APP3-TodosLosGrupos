

Matriz = [fila.split() for fila in open("input.txt")]

def fila_inicio():
  Matriz = [fila.split() for fila in open("input.txt")]
  return [i for i in range(len(Matriz[0])) if Matriz[i][0] == '0'][0]

def columna_salida():
  Matriz = [fila.split() for fila in open("input.txt")] 
  return len(Matriz) - 1

def fila_salida():
  Matriz = [fila.split() for fila in open("input.txt")] 
  return [i for i in range(len(Matriz[0])) if Matriz[i][len(Matriz) - 1] == '0'][0]

def Encontrar_camino(x, y): #revisa los vecinos de la posicion x,y
  return [[a, b] for a, b in [[x, y + 1], [x, y - 1], [x - 1, y], [x + 1, y]] if 0 <= b < len(Matriz) and 0 <= a < len(Matriz)] 
  

def main(Matriz, x = fila_inicio(), y = 0, camino = None): #funcion principal 

  Encontrar_camino(x, y) 
  
  if camino is None: #caso en que recien empecemos a buscar
    camino = [[x, y]] 
  
  if x == fila_salida() and y == columna_salida(): #caso en que estemos en la salida 
    yield camino
    
  else:  #buscando los caminos
    Matriz[x][y] = 1    

    for a, b in Encontrar_camino(x, y):
      if not Matriz[a][b]:
        yield from main(Matriz, a, b, camino + [[a, b]])
   
    Matriz[x][y] = 0 
    
def Crear_output(Matriz): #función para transformar cada elemento de la matriz de string a integer

  return [[int(x) for x in l] for l in Matriz]

print("Los caminos para resolver el laberinto son:",[elementos for elementos in main(Crear_output(Matriz))])
with open("output.txt", "w") as f: #archivo de salida
  f.write("".join([str(item) for item in [elementos for elementos in main(Crear_output(Matriz))]]))
